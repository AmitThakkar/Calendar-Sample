/**
 * Created by amitthakkar on 12/11/16.
 */
import {Component} from '@angular/core';
@Component({
    selector: 'app',
    template: '<calendar></calendar>'
})
export class AppComponent {
}
