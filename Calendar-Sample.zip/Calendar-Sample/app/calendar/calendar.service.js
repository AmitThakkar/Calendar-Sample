"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by amitthakkar on 12/11/16.
 */
var core_1 = require("@angular/core");
var MAX_WIDTH = 600;
var CalendarService = (function () {
    function CalendarService() {
    }
    CalendarService.prototype.getMeetings = function () {
        return [
            { id: 1, start: 0, end: 60 },
            { id: 2, start: 30, end: 90 },
            { id: 3, start: 120, end: 150 },
            { id: 4, start: 150, end: 210 },
            { id: 5, start: 210, end: 270 },
            { id: 6, start: 180, end: 240 },
            { id: 7, start: 270, end: 330 },
            { id: 8, start: 190, end: 230 },
            { id: 9, start: 390, end: 540 },
            { id: 10, start: 550, end: 610 },
            { id: 11, start: 660, end: 720 },
            { id: 12, start: 510, end: 540 },
            { id: 13, start: 390, end: 510 },
            { id: 14, start: 420, end: 520 },
            { id: 15, start: 580, end: 620 },
            { id: 16, start: 600, end: 640 }
        ];
    };
    CalendarService.prototype.getMeetingsWithPositions = function () {
        var meetingsWithCssAttributes = [];
        var conflicts = {};
        var meetingsLeft = {};
        var meetings = this.getMeetings();
        meetings.forEach(function (meeting) {
            var left = 0;
            for (var start = meeting.start; start < meeting.end; start++) {
                conflicts[start] ? conflicts[start]++ : conflicts[start] = 1;
                if (conflicts[start] > left + 1) {
                    left = conflicts[start] - 1;
                }
            }
            meetingsLeft[meeting.id] = left;
        });
        meetings.forEach(function (meeting) {
            var maxConflictMeeting = 1;
            for (var start = meeting.start; start < meeting.end; start++) {
                if (conflicts[start] > maxConflictMeeting) {
                    maxConflictMeeting = conflicts[start];
                }
            }
            meetingsWithCssAttributes.push({
                id: meeting.id,
                width: MAX_WIDTH / maxConflictMeeting,
                top: meeting.start * 2,
                height: (meeting.end * 2) - (meeting.start * 2),
                left: meetingsLeft[meeting.id] * MAX_WIDTH / maxConflictMeeting
            });
        });
        return meetingsWithCssAttributes;
    };
    CalendarService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], CalendarService);
    return CalendarService;
}());
exports.CalendarService = CalendarService;
//# sourceMappingURL=calendar.service.js.map